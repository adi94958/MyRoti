<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Sanctum\HasApiTokens;

class Pemilik extends Authenticatable
{
    use HasFactory, HasApiTokens;
    protected $table = 'pemiliks';
    protected $primaryKey = 'id_pemilik';
    protected $fillable = [
        'username', 
        'password', 
        'nama',
        'user_type'
    ];
}
